#include <stdio.h>
#include <string.h>

int main(){
    char s[1000];
    int i,j,l;
    scanf("%s",s);
    l=strlen(s);
    for(i=0;i<l;i++){
        for(j=i;j<l;j++){
            int k;
            for(k=i;k<=j;k++) putchar(s[k]);
            putchar('\n');
        }
    }
    return 0;
}
