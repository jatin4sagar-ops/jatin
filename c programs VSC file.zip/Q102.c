#include <stdio.h>

int main(){
    int n,x;
    scanf("%d",&n);
    int a[n],i,idx=-1;
    for(i=0;i<n;i++) scanf("%d",&a[i]);
    scanf("%d",&x);
    for(i=0;i<n;i++){
        if(a[i]>=x){ idx=i; break; }
    }
    printf("%d\n",idx);
    return 0;
}
