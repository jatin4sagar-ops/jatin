#include <stdio.h>

int main(){
    int n,k,i;
    scanf("%d",&n);
    int a[n];
    for(i=0;i<n;i++) scanf("%d",&a[i]);
    scanf("%d",&k);
    if(k>n||k<=0){ printf("0\n"); return 0; }
    long long window=0,maxsum;
    for(i=0;i<k;i++) window+=a[i];
    maxsum=window;
    for(i=k;i<n;i++){
        window+=a[i]-a[i-k];
        if(window>maxsum) maxsum=window;
    }
    printf("%lld\n",maxsum);
    return 0;
}
