#include <stdio.h>

int main(){
    int n,k,i,j;
    scanf("%d",&n);
    int a[n];
    for(i=0;i<n;i++) scanf("%d",&a[i]);
    scanf("%d",&k);
    if(k>n||k<=0) return 0;
    for(i=0;i<=n-k;i++){
        int val=0;
        for(j=i;j<i+k;j++){
            if(a[j]<0){ val=a[j]; break; }
        }
        printf("%d ",val);
    }
    printf("\n");
    return 0;
}
