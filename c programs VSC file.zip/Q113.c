#include <stdio.h>

void swap(int *a,int *b){int t=*a;*a=*b;*b=t;}

int main(){
    int n,k,i,j;
    scanf("%d",&n);
    int a[n];
    for(i=0;i<n;i++) scanf("%d",&a[i]);
    scanf("%d",&k);
    for(i=0;i<n-1;i++){
        for(j=i+1;j<n;j++){
            if(a[j]<a[i]) swap(&a[i],&a[j]);
        }
    }
    if(k>=1 && k<=n) printf("%d\n",a[k-1]);
    else printf("Invalid\n");
    return 0;
}
