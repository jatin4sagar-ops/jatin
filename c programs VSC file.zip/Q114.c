#include <stdio.h>
#include <string.h>

int main(){
    char s[1000];
    int last[256],i,start=0,maxlen=0,len;
    for(i=0;i<256;i++) last[i]=-1;
    fgets(s,sizeof(s),stdin);
    int n=strcspn(s,"\n");
    s[n]='\0';
    for(i=0;i<n;i++){
        unsigned char c=s[i];
        if(last[c]>=start) start=last[c]+1;
        last[c]=i;
        len=i-start+1;
        if(len>maxlen) maxlen=len;
    }
    printf("%d\n",maxlen);
    return 0;
}
