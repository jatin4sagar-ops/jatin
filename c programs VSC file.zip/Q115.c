#include <stdio.h>

int main(){
    char s[1000],t[1000];
    int cnt[26]={0},i;
    scanf("%s",s);
    scanf("%s",t);
    for(i=0;s[i];i++) cnt[s[i]-'a']++;
    for(i=0;t[i];i++) cnt[t[i]-'a']--;
    for(i=0;i<26;i++){
        if(cnt[i]!=0){
            printf("Not Anagram\n");
            return 0;
        }
    }
    printf("Anagram\n");
    return 0;
}
