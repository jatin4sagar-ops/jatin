#include <stdio.h>

int main(){
    int n,i;
    scanf("%d",&n);
    int a[n];
    for(i=0;i<n;i++) scanf("%d",&a[i]);
    int vis[n];
    for(i=0;i<n;i++) vis[i]=0;
    for(i=0;i<n;i++){
        if(vis[a[i]]){
            printf("%d\n",a[i]);
            return 0;
        }
        vis[a[i]]=1;
    }
    printf("No repeat\n");
    return 0;
}
