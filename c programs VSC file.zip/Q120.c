#include <stdio.h>
#include <ctype.h>

int main(){
    char s[1000];
    int i,newSentence=1;
    fgets(s,sizeof(s),stdin);
    for(i=0;s[i]!='\0';i++){
        if(newSentence && isalpha((unsigned char)s[i])){
            s[i]=toupper((unsigned char)s[i]);
            newSentence=0;
        }else{
            s[i]=tolower((unsigned char)s[i]);
        }
        if(s[i]=='.' || s[i]=='!' || s[i]=='?')
            newSentence=1;
        else if(!isspace((unsigned char)s[i]) && newSentence==1 && isalpha((unsigned char)s[i]))
            newSentence=0;
    }
    printf("%s",s);
    return 0;
}
