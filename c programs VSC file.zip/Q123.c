#include <stdio.h>
#include <ctype.h>

int main(){
    FILE *fp=fopen("input.txt","r");
    if(fp==NULL){
        printf("Cannot open file\n");
        return 1;
    }
    int c,chars=0,words=0,lines=0,inWord=0;
    while((c=fgetc(fp))!=EOF){
        chars++;
        if(c=='\n') lines++;
        if(!isspace(c)){
            if(!inWord){ words++; inWord=1; }
        }else inWord=0;
    }
    fclose(fp);
    printf("Chars: %d\nWords: %d\nLines: %d\n",chars,words,lines);
    return 0;
}
