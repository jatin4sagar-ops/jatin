#include <stdio.h>

int main(){
    char src[100],dest[100];
    printf("Source file: ");
    scanf("%s",src);
    printf("Destination file: ");
    scanf("%s",dest);
    FILE *fs=fopen(src,"r");
    if(fs==NULL){ printf("Cannot open source\n"); return 1; }
    FILE *fd=fopen(dest,"w");
    if(fd==NULL){ printf("Cannot open dest\n"); fclose(fs); return 1; }
    int c;
    while((c=fgetc(fs))!=EOF) fputc(c,fd);
    fclose(fs); fclose(fd);
    printf("Copied.\n");
    return 0;
}
