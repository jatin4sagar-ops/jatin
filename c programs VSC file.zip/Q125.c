#include <stdio.h>

int main(){
    char fname[100],line[256];
    printf("Filename: ");
    scanf("%s",fname);
    getchar();
    printf("Enter line to append:\n");
    fgets(line,sizeof(line),stdin);
    FILE *fp=fopen(fname,"a");
    if(fp==NULL){ printf("Cannot open file\n"); return 1; }
    fputs(line,fp);
    fclose(fp);
    printf("Appended.\n");
    return 0;
}
