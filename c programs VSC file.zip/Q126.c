#include <stdio.h>

int main(){
    char fname[100],line[256];
    scanf("%s",fname);
    FILE *fp=fopen(fname,"r");
    if(fp==NULL){
        printf("Error: file does not exist\n");
        return 1;
    }
    while(fgets(line,sizeof(line),fp)!=NULL)
        printf("%s",line);
    fclose(fp);
    return 0;
}
