#include <stdio.h>
#include <ctype.h>

int main(){
    FILE *fi=fopen("input.txt","r");
    FILE *fo=fopen("output.txt","w");
    if(!fi||!fo){ printf("File error\n"); return 1; }
    int c;
    while((c=fgetc(fi))!=EOF){
        if(islower(c)) c=toupper(c);
        fputc(c,fo);
    }
    fclose(fi); fclose(fo);
    return 0;
}
