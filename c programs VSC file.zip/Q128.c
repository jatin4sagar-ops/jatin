#include <stdio.h>
#include <ctype.h>

int main(){
    FILE *fp=fopen("input.txt","r");
    if(!fp){ printf("Error\n"); return 1; }
    int c,v=0,con=0;
    while((c=fgetc(fp))!=EOF){
        if(isalpha(c)){
            char x=tolower(c);
            if(x=='a'||x=='e'||x=='i'||x=='o'||x=='u') v++;
            else con++;
        }
    }
    fclose(fp);
    printf("Vowels: %d\nConsonants: %d\n",v,con);
    return 0;
}
