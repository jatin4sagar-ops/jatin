#include <stdio.h>

struct Student{
    char name[100];
    int roll;
    float marks;
};

int main(){
    int n,i;
    printf("Number of students: ");
    scanf("%d",&n);
    struct Student s;
    FILE *fp=fopen("students.txt","w");
    if(!fp){ printf("Error\n"); return 1; }
    for(i=0;i<n;i++){
        printf("Name: ");
        getchar();
        fgets(s.name,sizeof(s.name),stdin);
        printf("Roll: ");
        scanf("%d",&s.roll);
        printf("Marks: ");
        scanf("%f",&s.marks);
        fprintf(fp,"%s %d %.2f\n",s.name,s.roll,s.marks);
    }
    fclose(fp);

    fp=fopen("students.txt","r");
    if(!fp){ printf("Error\n"); return 1; }
    printf("\nRecords:\n");
    while(fscanf(fp," %[^\n] %d %f",s.name,&s.roll,&s.marks)==3){
        printf("Name: %s, Roll: %d, Marks: %.2f\n",s.name,s.roll,s.marks);
    }
    fclose(fp);
    return 0;
}
