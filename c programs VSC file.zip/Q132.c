#include <stdio.h>

enum Light{RED,YELLOW,GREEN};

int main(){
    enum Light l;
    scanf("%d",(int*)&l);
    if(l==RED) printf("Stop\n");
    else if(l==YELLOW) printf("Wait\n");
    else if(l==GREEN) printf("Go\n");
    else printf("Invalid\n");
    return 0;
}
