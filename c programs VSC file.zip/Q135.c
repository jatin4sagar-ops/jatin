#include <stdio.h>

enum Codes{A=10,B,C,D};

int main(){
    printf("A=%d B=%d C=%d D=%d\n",A,B,C,D);
    return 0;
}
