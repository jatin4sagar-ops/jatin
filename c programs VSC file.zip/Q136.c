#include <stdio.h>

enum Menu{ADD=1,SUBTRACT,MULTIPLY};

int main(){
    int a,b,ch;
    scanf("%d%d",&a,&b);
    printf("1.Add 2.Subtract 3.Multiply\n");
    scanf("%d",&ch);
    switch(ch){
        case ADD: printf("%d\n",a+b); break;
        case SUBTRACT: printf("%d\n",a-b); break;
        case MULTIPLY: printf("%d\n",a*b); break;
        default: printf("Invalid\n");
    }
    return 0;
}
