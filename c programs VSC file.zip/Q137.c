#include <stdio.h>

enum Role{ADMIN,USER,GUEST};

int main(){
    enum Role r;
    scanf("%d",(int*)&r);
    if(r==ADMIN) printf("Welcome, admin\n");
    else if(r==USER) printf("Welcome, user\n");
    else if(r==GUEST) printf("Welcome, guest\n");
    else printf("Unknown role\n");
    return 0;
}
