#include <stdio.h>

enum Color{RED_C,GREEN_C,BLUE_C};

int main(){
    enum Color c;
    for(c=RED_C;c<=BLUE_C;c++){
        if(c==RED_C) printf("RED %d\n",c);
        else if(c==GREEN_C) printf("GREEN %d\n",c);
        else if(c==BLUE_C) printf("BLUE %d\n",c);
    }
    return 0;
}
