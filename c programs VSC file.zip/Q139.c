#include <stdio.h>

enum Test{X=5,Y,Z};

int main(){
    printf("X=%d Y=%d Z=%d\n",X,Y,Z);
    return 0;
}
