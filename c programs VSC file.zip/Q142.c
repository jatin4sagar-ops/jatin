#include <stdio.h>

struct Student{
    char name[100];
    int roll_no;
    float marks;
};

int main(){
    struct Student s[5];
    int i;
    for(i=0;i<5;i++){
        printf("Student %d name: ",i+1);
        getchar();
        fgets(s[i].name,sizeof(s[i].name),stdin);
        printf("Roll: ");
        scanf("%d",&s[i].roll_no);
        printf("Marks: ");
        scanf("%f",&s[i].marks);
    }
    for(i=0;i<5;i++){
        printf("Name: %sRoll: %d Marks: %.2f\n",s[i].name,s[i].roll_no,s[i].marks);
    }
    return 0;
}
