#include <stdio.h>

struct Student{
    char name[100];
    int roll_no;
    float marks;
};

int main(){
    int n,i,idx=0;
    scanf("%d",&n);
    struct Student s[n];
    getchar();
    for(i=0;i<n;i++){
        fgets(s[i].name,sizeof(s[i].name),stdin);
        scanf("%d",&s[i].roll_no);
        scanf("%f",&s[i].marks);
        getchar();
    }
    for(i=1;i<n;i++)
        if(s[i].marks>s[idx].marks) idx=i;
    printf("Topper: %sRoll: %d Marks: %.2f\n",s[idx].name,s[idx].roll_no,s[idx].marks);
    return 0;
}
