#include <stdio.h>

struct Student{
    char name[100];
    int roll_no;
    float marks;
};

void printStudent(struct Student s){
    printf("Name: %sRoll: %d Marks: %.2f\n",s.name,s.roll_no,s.marks);
}

int main(){
    struct Student s;
    fgets(s.name,sizeof(s.name),stdin);
    scanf("%d",&s.roll_no);
    scanf("%f",&s.marks);
    printStudent(s);
    return 0;
}
