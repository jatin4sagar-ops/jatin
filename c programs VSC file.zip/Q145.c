#include <stdio.h>

struct Student{
    char name[100];
    int roll_no;
    float marks;
};

struct Student getTopper(struct Student s[],int n){
    int i,idx=0;
    for(i=1;i<n;i++)
        if(s[i].marks>s[idx].marks) idx=i;
    return s[idx];
}

int main(){
    int n,i;
    scanf("%d",&n);
    struct Student s[n];
    getchar();
    for(i=0;i<n;i++){
        fgets(s[i].name,sizeof(s[i].name),stdin);
        scanf("%d",&s[i].roll_no);
        scanf("%f",&s[i].marks);
        getchar();
    }
    struct Student t=getTopper(s,n);
    printf("Topper: %sRoll: %d Marks: %.2f\n",t.name,t.roll_no,t.marks);
    return 0;
}
