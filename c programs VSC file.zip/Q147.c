#include <stdio.h>

struct Employee{
    char name[100];
    int id;
    float salary;
};

int main(){
    int n,i;
    scanf("%d",&n);
    struct Employee e;
    FILE *fp=fopen("emp.bin","wb");
    if(!fp){ printf("Error\n"); return 1; }
    getchar();
    for(i=0;i<n;i++){
        fgets(e.name,sizeof(e.name),stdin);
        scanf("%d",&e.id);
        scanf("%f",&e.salary);
        getchar();
        fwrite(&e,sizeof(e),1,fp);
    }
    fclose(fp);

    fp=fopen("emp.bin","rb");
    if(!fp){ printf("Error\n"); return 1; }
    printf("Employees:\n");
    while(fread(&e,sizeof(e),1,fp)==1){
        printf("Name: %sID: %d Salary: %.2f\n",e.name,e.id,e.salary);
    }
    fclose(fp);
    return 0;
}
