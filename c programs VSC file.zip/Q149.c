#include <stdio.h>
#include <stdlib.h>

struct Student{
    char name[100];
    int roll;
    float marks;
};

int main(){
    struct Student *s=(struct Student*)malloc(sizeof(struct Student));
    if(!s){ printf("Memory error\n"); return 1; }
    fgets(s->name,sizeof(s->name),stdin);
    scanf("%d",&s->roll);
    scanf("%f",&s->marks);
    printf("Name: %sRoll: %d Marks: %.2f\n",s->name,s->roll,s->marks);
    free(s);
    return 0;
}
