#include <stdio.h>
#include <ctype.h>

int is_vowel(char c){
    c = tolower((unsigned char)c);
    return c=='a'||c=='e'||c=='i'||c=='o'||c=='u';
}

int main(){
    char s[1000], out[1000];
    int i,j=0;
    fgets(s,sizeof(s),stdin);
    for(i=0;s[i]!='\0';i++){
        if(s[i]=='\n') break;
        if(!is_vowel(s[i])) out[j++]=s[i];
    }
    out[j]='\0';
    printf("%s",out);
    return 0;
}
