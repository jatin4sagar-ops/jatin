#include <stdio.h>

int main(){
    char s[1000];
    int freq[26]={0},i,idx;
    fgets(s,sizeof(s),stdin);
    for(i=0;s[i]!='\0';i++){
        if(s[i]<'a'||s[i]>'z') continue;
        idx=s[i]-'a';
        if(freq[idx]==1){
            printf("%c\n",s[i]);
            return 0;
        }
        freq[idx]++;
    }
    printf("No repeating lowercase alphabet\n");
    return 0;
}
