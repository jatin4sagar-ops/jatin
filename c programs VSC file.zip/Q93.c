#include <stdio.h>
#include <string.h>
#include <ctype.h>

int main(){
    char a[1000],b[1000];
    int cnt[256]={0},i;
    fgets(a,sizeof(a),stdin);
    fgets(b,sizeof(b),stdin);
    for(i=0;a[i];i++){
        if(a[i]=='\n') break;
        cnt[(unsigned char)tolower((unsigned char)a[i])]++;
    }
    for(i=0;b[i];i++){
        if(b[i]=='\n') break;
        cnt[(unsigned char)tolower((unsigned char)b[i])]--;
    }
    for(i=0;i<256;i++){
        if(cnt[i]!=0){
            printf("Not Anagram\n");
            return 0;
        }
    }
    printf("Anagram\n");
    return 0;
}
