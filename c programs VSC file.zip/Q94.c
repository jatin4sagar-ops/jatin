#include <stdio.h>
#include <string.h>

int main(){
    char s[1000];
    char longest[1000];
    int i=0,start=0,len=0,maxlen=0,maxstart=0;
    fgets(s,sizeof(s),stdin);
    while(1){
        if(s[i]==' '||s[i]=='\n'||s[i]=='\0'){
            if(len>0 && len>maxlen){
                maxlen=len;
                maxstart=start;
            }
            if(s[i]=='\0'||s[i]=='\n') break;
            len=0;
        }else{
            if(len==0) start=i;
            len++;
        }
        i++;
    }
    strncpy(longest,s+maxstart,maxlen);
    longest[maxlen]='\0';
    printf("%s\n",longest);
    return 0;
}
