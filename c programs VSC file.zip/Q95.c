#include <stdio.h>
#include <string.h>

int main(){
    char s1[1000],s2[1000],cat[2000];
    fgets(s1,sizeof(s1),stdin);
    fgets(s2,sizeof(s2),stdin);
    s1[strcspn(s1,"\n")]=0;
    s2[strcspn(s2,"\n")]=0;
    if(strlen(s1)!=strlen(s2)){
        printf("Not Rotation\n");
        return 0;
    }
    strcpy(cat,s1);
    strcat(cat,s1);
    if(strstr(cat,s2)) printf("Rotation\n");
    else printf("Not Rotation\n");
    return 0;
}
