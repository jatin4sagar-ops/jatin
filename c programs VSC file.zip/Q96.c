#include <stdio.h>
#include <string.h>

void reverse(char *s,int l,int r){
    while(l<r){
        char t=s[l]; s[l]=s[r]; s[r]=t;
        l++; r--;
    }
}

int main(){
    char s[1000];
    int i=0,start=-1;
    fgets(s,sizeof(s),stdin);
    while(1){
        if(s[i]==' '||s[i]=='\n'||s[i]=='\0'){
            if(start!=-1){
                reverse(s,start,i-1);
                start=-1;
            }
            if(s[i]=='\0'||s[i]=='\n') break;
        }else{
            if(start==-1) start=i;
        }
        i++;
    }
    printf("%s",s);
    return 0;
}
