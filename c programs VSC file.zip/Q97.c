#include <stdio.h>
#include <ctype.h>

int main(){
    char s[200];
    int i;
    fgets(s,sizeof(s),stdin);
    if(s[0]!=' ' && s[0]!='\n') printf("%c",toupper((unsigned char)s[0]));
    for(i=1;s[i]!='\0';i++){
        if(s[i-1]==' ' && s[i]!=' ' && s[i]!='\n')
            printf(" %c",toupper((unsigned char)s[i]));
    }
    printf("\n");
    return 0;
}
