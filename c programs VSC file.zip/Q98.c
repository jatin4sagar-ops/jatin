#include <stdio.h>
#include <string.h>
#include <ctype.h>

int main(){
    char s[200],words[20][50];
    int i=0,j=0,w=0;
    fgets(s,sizeof(s),stdin);
    for(i=0;s[i]!='\0';i++){
        if(s[i]==' '||s[i]=='\n'){
            if(j>0){
                words[w][j]='\0';
                w++; j=0;
            }
        }else{
            words[w][j++]=s[i];
        }
    }
    if(j>0){ words[w][j]='\0'; w++; }
    if(w==0) return 0;
    for(i=0;i<w-1;i++)
        printf("%c. ",toupper((unsigned char)words[i][0]));
    printf("%s\n",words[w-1]);
    return 0;
}
