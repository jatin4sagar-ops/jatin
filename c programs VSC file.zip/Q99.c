#include <stdio.h>

int main(){
    int d,m,y;
    char *mon[]={"Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"};
    scanf("%d/%d/%d",&d,&m,&y);
    if(m<1||m>12){
        printf("Invalid\n");
        return 0;
    }
    printf("%02d-%s-%04d\n",d,mon[m-1],y);
    return 0;
}
