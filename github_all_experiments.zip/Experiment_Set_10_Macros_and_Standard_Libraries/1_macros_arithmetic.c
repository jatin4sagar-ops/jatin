#include <stdio.h>
#define ADD(a,b) ((a)+(b))
#define MUL(a,b) ((a)*(b))
int main(){ printf("%d %d\n", ADD(3,4), MUL(3,4)); return 0; }