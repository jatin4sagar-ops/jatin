#include <stdio.h>
#include <string.h>
#include <math.h>
int main(){ char s[]="Hello"; printf("Len=%zu Round(2.7)=%.0f\n", strlen(s), round(2.7)); return 0; }