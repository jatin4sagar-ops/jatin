#include <stdio.h>
int main(){ int x=10; printf("Value: %d\nAddress: %p\n", x, (void*)&x); return 0; }