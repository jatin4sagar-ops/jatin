#include <stdio.h>
int main(){ int n,sum=0; printf("Enter an integer: "); scanf("%d",&n); int t=n; while(t){ sum+=t%10; t/=10;} printf("Sum of digits of %d is %d\n", n, sum); return 0; }