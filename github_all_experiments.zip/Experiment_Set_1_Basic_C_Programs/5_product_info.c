#include <stdio.h>
struct Product{ char name[30]; int id; int quantity; float price; char manufacturer[30]; char category[30];};
int main(){ struct Product p; printf("Product Name: "); scanf("%s", p.name); printf("Product ID: "); scanf("%d",&p.id);
printf("Quantity: "); scanf("%d",&p.quantity); printf("Price: "); scanf("%f",&p.price); printf("Manufacturer: "); scanf("%s", p.manufacturer);
printf("Category: "); scanf("%s", p.category);
printf("\nProduct Details:\nName:%s\nID:%d\nQty:%d\nPrice:%.2f\nManufacturer:%s\nCategory:%s\n",
p.name,p.id,p.quantity,p.price,p.manufacturer,p.category); return 0; }