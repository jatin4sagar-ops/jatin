#include <stdio.h>
struct Book{ char title[50]; char author[30]; int isbn; float price; char publisher[30]; int year;};
int main(){ struct Book b; printf("Book Title: "); scanf("%s", b.title); printf("Author Name: "); scanf("%s", b.author);
printf("ISBN: "); scanf("%d", &b.isbn); printf("Price: "); scanf("%f",&b.price); printf("Publisher: "); scanf("%s", b.publisher);
printf("Year of Publication: "); scanf("%d",&b.year);
printf("\nBook Details:\nTitle:%s\nAuthor:%s\nISBN:%d\nPrice:%.2f\nPublisher:%s\nYear:%d\n",
b.title,b.author,b.isbn,b.price,b.publisher,b.year); return 0; }