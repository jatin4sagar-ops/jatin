#include <stdio.h>
struct Mobile{ char brand[30]; char model[30]; int serial; float price; char color[20]; int battery;};
int main(){ struct Mobile m; printf("Brand: "); scanf("%s", m.brand); printf("Model: "); scanf("%s", m.model);
printf("Serial No: "); scanf("%d",&m.serial); printf("Price: "); scanf("%f",&m.price); printf("Color: "); scanf("%s", m.color);
printf("Battery (mAh): "); scanf("%d",&m.battery);
printf("\nMobile Details:\nBrand:%s\nModel:%s\nSerial:%d\nPrice:%.2f\nColor:%s\nBattery:%dmAh\n",
m.brand,m.model,m.serial,m.price,m.color,m.battery); return 0; }