#include <stdio.h>
#include <math.h>
int main(){ double a,b,c; printf("Enter a b c: "); if(scanf("%lf%lf%lf",&a,&b,&c)==3){ double D=b*b-4*a*c; if(D>0) printf("Roots: %lf and %lf\n",(-b+sqrt(D))/(2*a),(-b-sqrt(D))/(2*a)); else if(D==0) printf("One root: %lf\n",-b/(2*a)); else printf("Complex roots\n"); } return 0; }