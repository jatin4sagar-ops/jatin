#include <stdio.h>
int main(){ int a,b,c; printf("Enter three ints: "); if(scanf("%d%d%d",&a,&b,&c)==3){ int max=(a>b)?a:b; if(c>max) max=c; printf("Largest=%d\n",max);} return 0; }