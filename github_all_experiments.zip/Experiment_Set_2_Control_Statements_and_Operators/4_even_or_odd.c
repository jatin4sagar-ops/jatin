#include <stdio.h>
int main(){ int n; printf("Enter n: "); if(scanf("%d",&n)==1) printf("%d is %s\n", n, (n%2==0)? "Even":"Odd"); return 0; }