#include <stdio.h>
int main(){ int a,b; printf("Enter a b: "); if(scanf("%d%d",&a,&b)==2) printf("Quotient=%d Remainder=%d\n", a/b, a%b); return 0; }