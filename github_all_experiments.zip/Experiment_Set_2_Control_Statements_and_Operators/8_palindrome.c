#include <stdio.h>
int main(){ int n,t,rev=0; printf("Enter n: "); scanf("%d",&n); t=n; while(t){ rev=rev*10 + t%10; t/=10;} printf((rev==n)? "Palindrome\n":"Not Palindrome\n"); return 0; }