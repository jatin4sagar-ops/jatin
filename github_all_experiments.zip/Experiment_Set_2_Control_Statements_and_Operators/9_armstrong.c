#include <stdio.h>
int main(){ int n,t,sum=0; printf("Enter n: "); scanf("%d",&n); t=n; while(t){ int d=t%10; sum+=d*d*d; t/=10;} printf((sum==n)? "Armstrong\n":"Not Armstrong\n"); return 0; }