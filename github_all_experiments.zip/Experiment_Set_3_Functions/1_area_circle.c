#include <stdio.h>
#define PI 3.14159265
double area(double r){ return PI*r*r; }
int main(){ double r; printf("Radius: "); scanf("%lf",&r); printf("Area=%.3f\n", area(r)); return 0; }