#include <stdio.h>
void display(char name[], int roll, int marks){ printf("Name:%s Roll:%d Marks:%d\n", name, roll, marks); }
int main(){ char name[30]="Aman"; display(name,12,87); return 0; }