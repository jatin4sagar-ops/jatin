#include <stdio.h>
struct Emp{ char name[30]; int id; char dept[20]; float salary;};
void display(struct Emp e){ printf("Name:%s ID:%d Dept:%s Salary:%.2f\n", e.name,e.id,e.dept,e.salary); }
int main(){ struct Emp e; printf("Name: "); scanf("%s", e.name); printf("ID: "); scanf("%d",&e.id);
printf("Dept: "); scanf("%s", e.dept); printf("Salary: "); scanf("%f",&e.salary); display(e); return 0; }