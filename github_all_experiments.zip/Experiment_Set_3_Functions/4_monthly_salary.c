#include <stdio.h>
float monthly(float basic, int metro){
    float hra = (metro?0.15f:0.10f)*basic;
    float da = 0.05f*basic;
    return basic + hra + da;
}
int main(){ float basic; int metro; printf("Basic: "); scanf("%f",&basic); printf("Metro? (1/0): "); scanf("%d",&metro);
printf("Monthly Salary=%.2f\n", monthly(basic, metro)); return 0; }