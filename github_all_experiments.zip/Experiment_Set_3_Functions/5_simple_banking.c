#include <stdio.h>
int main(){ float bal=0; int ch; float amt;
do{ printf("\n1:Deposit 2:Withdraw 3:Check 0:Exit\nChoice: "); scanf("%d",&ch);
    switch(ch){ case 1: printf("Amt: "); scanf("%f",&amt); bal+=amt; break;
                 case 2: printf("Amt: "); scanf("%f",&amt); if(amt<=bal) bal-=amt; else printf("Insufficient\n"); break;
                 case 3: printf("Balance=%.2f\n", bal); break; }
}while(ch!=0); return 0; }