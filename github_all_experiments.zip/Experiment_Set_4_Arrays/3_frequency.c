#include <stdio.h>
int main(){ int a[]={1,2,3,2,4,2,5}, key=2, freq=0; for(int i=0;i<7;i++) if(a[i]==key) freq++; printf("Frequency of %d is %d\n", key, freq); return 0; }