#include <stdio.h>
int g = 10; void foo(){ printf("g in foo = %d\n", g); } int main(){ int g=5; printf("g in main = %d\n", g); foo(); return 0; }