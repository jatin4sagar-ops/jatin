#include <stdio.h>
int main(){ int x=10; { int x=20; printf("inner x=%d\n", x);} printf("outer x=%d\n", x); return 0; }