#include <stdio.h>
int main(){ int x=1; { int x=2; printf("inner x=%d\n",x);} printf("outer x=%d\n", x); return 0; }