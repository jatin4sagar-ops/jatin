#include <stdio.h>
struct Book{ int book_id; char title[30]; char author[30]; float price; };
void printBook(struct Book b){ printf("ID=%d Title=%s Author=%s Price=%.2f\n", b.book_id, b.title, b.author, b.price); }
int main(){ struct Book bk={101, "C_Prog", "K&R", 249.99}; printBook(bk); return 0; }