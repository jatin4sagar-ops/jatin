#include <stdio.h>
#include <string.h>
union Addr{ char name[50]; char home_address[100]; char hostel_address[100]; char city[30]; char state[30]; char zip[10]; };
int main(){ union Addr a; strcpy(a.home_address, "12 Baker Street"); printf("Present Address: %s\n", a.home_address); return 0; }