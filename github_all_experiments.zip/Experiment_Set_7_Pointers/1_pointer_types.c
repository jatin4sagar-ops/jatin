#include <stdio.h>
int main(){ int i=10; float f=3.14; char c='A'; int *pi=&i; float *pf=&f; char *pc=&c; printf("%d %f %c\n", *pi, *pf, *pc); return 0; }