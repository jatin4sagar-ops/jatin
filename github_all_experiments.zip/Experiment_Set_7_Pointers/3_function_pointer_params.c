#include <stdio.h>
void inc(int *x){ (*x)++; }
int main(){ int a=5; inc(&a); printf("a=%d\n", a); return 0; }