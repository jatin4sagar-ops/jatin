#include <stdio.h>
#include <stdlib.h>
int main(){ int n=5; int *a = malloc(n*sizeof(int)); int vals[]={5,2,9,1,7}; for(int i=0;i<n;i++) a[i]=vals[i]; int sum=0,mx=a[0],mn=a[0]; for(int i=0;i<n;i++){ sum+=a[i]; if(a[i]>mx) mx=a[i]; if(a[i]<mn) mn=a[i]; } printf("Sum=%d Max=%d Min=%d\n", sum, mx, mn); free(a); return 0; }