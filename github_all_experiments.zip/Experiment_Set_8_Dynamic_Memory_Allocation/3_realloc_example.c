#include <stdio.h>
#include <stdlib.h>
int main(){ int *a = malloc(3*sizeof(int)); a[0]=1;a[1]=2;a[2]=3; a = realloc(a,5*sizeof(int)); a[3]=4; a[4]=5; for(int i=0;i<5;i++) printf("%d ", a[i]); printf("\n"); free(a); return 0; }