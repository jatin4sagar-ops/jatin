#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int main(){ char *s = malloc(16); strcpy(s, "Hello"); s = realloc(s, 32); strcat(s, "_World"); printf("%s\n", s); free(s); return 0; }