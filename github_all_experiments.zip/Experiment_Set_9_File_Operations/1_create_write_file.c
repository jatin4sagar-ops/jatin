#include <stdio.h>
int main(){ FILE *f=fopen("out.txt","w"); fprintf(f, "Hello File\n"); fclose(f); printf("Written\n"); return 0; }