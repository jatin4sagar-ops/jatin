#include <stdio.h>
#include <ctype.h>
int main(){ FILE *f=fopen("out.txt","r"); int c, inword=0, words=0; while((c=fgetc(f))!=EOF){ if(isspace(c)) inword=0; else if(!inword){ inword=1; words++; } } fclose(f); printf("Words=%d\n", words); return 0; }